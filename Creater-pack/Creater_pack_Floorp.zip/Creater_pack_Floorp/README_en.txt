
Thank you for downloading the Floorp project and creator pack.

This pack contains icons, headers, and link images that can be used to introduce the Floorp project itself or the Floorp legacy browser on blogs, social networking sites, etc.
It contains icons, headers, and link images that can be used on blogs, social networking sites, etc. to introduce the Floorp project itself, or to introduce the Floorp legacy browser. Any other use is not permitted.

If you plan to use anything other than the above, please contact the official Ablaze support website at https://support.ablaze.one or the official Ablaze support Twitter at https://twitter.com/ablaze_support.

--------------------------

First of all, thank you very much for using and referring us to Floorp. Thank you very much.

About the license of icons

All icons and header images are copyrighted by Ablaze, the Floorp project, and other third parties. They are not license free.
Modification is also prohibited. If you find an image you want, please visit the support section above.

2. Browser icons and other items included in the source code of the Florp legacy browser are not licensed under the Mozilla Public License 2.0 (commonly known as MPL2.0). 
Therefore, please do not pull out any icons from the source code.

You may use screenshots of the Floorp legacy browser on social networking sites and blogs.

4. You may only use this creator pack to introduce the Floorp legacy browser or the Floorp project.

--------------------------
About Images

The Ablaze_img folder contains images about Ablaze, and the Floorp_imgs folder contains icons for the Floorp project or the Floorp legacy browser. svg and png formats are available.

Available in svg and png formats.

--------------------------
About the Floorp brand

Floorp currently has two icons: "Floorp_imgs\Floorp_Bland" contains the Floorp icon for the Floorp project. This is new in 8.3.6.
Please use this to introduce your project.

Floorp_imgs\Floorp_Legacy" contains the icon for the Floorp legacy browser. Please use this icon to introduce the browser.

That's all! Thank you for reading this far. Please let me know when you finish the blog, etc.! I'd be happy to take a look.
